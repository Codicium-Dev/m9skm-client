import React, { useState } from 'react'

const Contacts = () => {
  const viberLink = "https://invite.viber.com/?g2=AQAT5AzzN9mJu1KWiT7C2b13nFsiS%2BXoheXLWNkGofLJQxcxCvsS6LWydWhtNBE9"

  const telegramLink = "https://t.me/+XsUcIYJ9U4NjYzhl"

  const phoneNumber = "09776155260";

  return (
    {viberLink, telegramLink, phoneNumber}
  )
}

export default Contacts